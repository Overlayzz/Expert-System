import csv
import sys

from PyQt5 import QtWidgets
from PyQt5.QtWidgets import QTableWidgetItem, QMessageBox

from Classes import Dish, Product
from f import Form
from Lab_3 import *


def log_uncaught_exceptions(ex_cls, ex, tb):
    text = f"{ex_cls.__name__}: {ex}:\n"
    import traceback
    text += ''.join(traceback.format_tb(tb))
    print(f"\n{text}\n")


sys.excepthook = log_uncaught_exceptions  # noqa


class GUI(QtWidgets.QMainWindow, Form.Ui_MainWindow):

    def __init__(self):
        super().__init__()
        self.setupUi(self)  # инициализация дизайна
        self.setWindowTitle('Lab_1')

        self.data_dishes = []
        self.data_products = []
        self.data_humans = []
        self.refresh_mode = True
        self.cliced_row = None
        self.header_data = ["Название", "Белки", "Жиры", "Углеводы", "Калории", "Состав", "Цена"]

        self.comboBox.currentTextChanged.connect(self.fill_table)
        self.tableWidget.cellClicked.connect(self.set_row)

        self.pushButton.clicked.connect(self.delete_row)
        self.pushButton_2.clicked.connect(self.create_row)
        self.pushButton_3.clicked.connect(self.save_changes)

        self.read_csv()
        self.fill_table()

    def fill_table(self):
        if self.comboBox.currentText() == "Блюда":
            data = self.data_dishes

        elif self.comboBox.currentText() == "Продукты":
            data = self.data_products

        self.refresh_mode = False
        self.tableWidget.setRowCount(0)
        self.tableWidget.setColumnCount(0)

        i = 0
        row_num = max(len(row) for row in data)
        self.tableWidget.setColumnCount(row_num - 1)
        for row in data:
            self.tableWidget.insertRow(self.tableWidget.rowCount())
            for j in range(1, len(row)):
                # self.tableWidget.insertRow(self.tableWidget.rowCount())
                cell_item = QTableWidgetItem()
                cell_item.setText(row[j])
                self.tableWidget.setItem(i, j - 1, cell_item)
            i += 1
        self.refresh_mode = True

        self.tableWidget.setHorizontalHeaderLabels(self.header_data)

    def read_csv(self, path='ClassesData.csv'):  # noqa
        with open(path, encoding='utf-8') as class_file:
            file_reader = csv.reader(class_file, delimiter=",")
            data = []
            for row in file_reader:
                if row[0] == "Dish":
                    self.data_dishes.append(row)
                elif row[0] == "Product":
                    self.data_products.append(row)
                else:
                    print("?" + str(row))
        return data

    def check_for_completion(self, row_pos: int) -> bool:
        for i in range(0, self.tableWidget.columnCount()):
            if self.tableWidget.item(row_pos, i).text() == ' ':
                return False
        print('ok')
        return True

    def save_changes(self, row_pos=None):

        data_to_save = []

        if self.comboBox.currentText() == "Блюда":
            data_to_save = self.fill_list_form_list(self.data_products, data_to_save)
        elif self.comboBox.currentText() == "Продукты":
            data_to_save = self.fill_list_form_list(self.data_dishes, data_to_save)

        data_to_save = self.fill_from_currnet_table(data_to_save)

        if data_to_save:
            with open("ClassesData.csv", mode="w", encoding="utf-8") as class_file:
                file_writer = csv.writer(class_file, delimiter=",", lineterminator="\r")
                for row in data_to_save:
                    file_writer.writerow(row)

    def fill_list_form_list(self, data_list, data_to_save):
        for l in data_list:
            data_to_save.append(l)
        return data_to_save

    def fill_from_currnet_table(self, data_to_save):
        if self.comboBox.currentText() == "Блюда":
            try:
                for i in range(self.tableWidget.rowCount()):
                    row = []
                    for j in range(0, self.tableWidget.columnCount()):
                        row.append(self.tableWidget.item(i, j).text())

                    tempClass = Dish(row[0], float(row[1]), float(row[2]), float(row[3]), float(row[5]), row[5], int(row[1]))
                    csv_list = list(tempClass.__dict__.values())
                    csv_list.insert(0, tempClass.__class__.__name__)
                    row.insert(0, Dish.__class__.__name__)
                    data_to_save.append(csv_list)
                return data_to_save
            except:
                QMessageBox.critical(self, "Ошибка", "Неверные значения", QMessageBox.Ok)
                return None

        else:
            try:
                for i in range(self.tableWidget.rowCount()):
                    row = []
                    for j in range(0, self.tableWidget.columnCount()):
                        row.append(self.tableWidget.item(i, j).text())

                    tempClass = Product(row[0], row[1], row[2], row[3], row[4])
                    csv_list = list(tempClass.__dict__.values())
                    csv_list.insert(0, tempClass.__class__.__name__)
                    row.insert(0, Dish.__class__.__name__)
                    data_to_save.append(csv_list)
                return data_to_save
            except:
                QMessageBox.critical(self, "Ошибка", "Неверные значения", QMessageBox.Ok)



    def create_row(self):
        self.refresh_mode = False
        if self.check_for_completion(self.tableWidget.rowCount() - 1):
            self.tableWidget.insertRow(self.tableWidget.rowCount())

    def set_row(self, row, _):
        self.cliced_row = row
        print(row)

    def delete_row(self):
        self.tableWidget.removeRow(self.cliced_row)


def main():
    app = QtWidgets.QApplication(sys.argv)  # Новый экземпляр QApplication
    window = GUI()  # создаём объект класса приложения
    window.show()  # показываем окно
    app.exec_()  # запускаем приложение


if __name__ == '__main__':
    main()

# при изменении в таблице идёт проверка
# при добавлении создовать окно
