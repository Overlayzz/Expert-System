import csv
from Сours.Classes import Dish, Product


def write_to_csv(object_list: list) -> None:

    for someObject in object_list:

        with open("ClassesData.csv", mode="a", encoding="utf-8") as class_file:
            file_writer = csv.writer(class_file, delimiter=",", lineterminator="\r")
            csv_list = list(someObject.__dict__.values())
            csv_list.insert(0, someObject.__class__.__name__)
            file_writer.writerow(csv_list)


def read_from_csv(path='ClassesData.csv') -> list:
    with open(path, encoding='utf-8') as class_file:
        file_reader = csv.reader(class_file, delimiter=",")
        object_list = []  # noqa
        for row in file_reader:
            if row[0] == "Product":
                object_list.append(Product(row[1], row[2], row[3], row[4], row[5]))
            elif row[0] == "Dish":
                object_list.append(Dish(row[1], row[2], row[3], row[4], row[5],row[6], row[7]))

    return object_list


if __name__ == '__main__':
    # удаление записией из файлов
    open("ClassesData.csv", mode="w", encoding="utf-8")

    egg = Product("Egg", 12.7, 11.5, 0.7, 157)
    potato = Product("Potato", 2, 0.4, 16.3, 77)
    fish = Product("Fish", 19.9, 7, 1, 143)
    meat = Product("Meat", 20.4, 8.6, 0.4, 161)
    cheese = Product("Cheese", 12.1, 25.3, 2, 26.36)
    cream = Product("Cream", 2.5, 20, 3.4, 206)
    oil = Product("Olive oil", 0.27, 90.71, 1.68, 10)
    nut = Product("Nut", 15.6, 62.2, 10.2, 50)
    tomato = Product("Tomato", 1.1, 0.2, 5.2, 24)
    cottage_cheese = Product("Cottage cheese", 14, 18, 1.8, 26)
    milk = Product("Milk", 3.2, 3.6, 4.8, 32)
    onion = Product("Onion", 0.97, 0.47, 5.74, 27)

    cooked_meat = Dish("Cooked meat", 28.93, 7.41, 0, 190, [meat.get_title()], 550)
    picasso_chicken = Dish("Picasso Chicken", 69.6, 30.7, 21.2, 637, [meat.get_title(), tomato.get_title(), cheese.get_title(), oil.get_title(), nut.get_title()], 1037)
    cheesecakes = Dish("Cheesecakes", 13, 19.4, 19.6, 30, [cottage_cheese.get_title(), egg.get_title(), oil.get_title()], 320)
    lasagna = Dish("Lasagna", 11.69, 12.49, 21.78, 270, [meat.get_title(), tomato.get_title(), oil.get_title(), cheese.get_title()], 600)
    pancakes = Dish("Pancakes", 26.7, 27.4, 95.4, 733, [milk.get_title(), egg.get_title(), oil.get_title()], 250)
    azu = Dish("Azu", 32.7, 16.9, 65.9, 525, [meat.get_title(), tomato.get_title(), potato.get_title()], 900)
    oyakodon = Dish("Oyakodon", 112.5, 23.9, 127.3, 1190, [meat.get_title(), egg.get_title(), onion.get_title()], 1200)

    product_list = [egg, potato, fish, meat, cheese, cream, oil, nut, tomato, cottage_cheese, milk, onion]
    dish_list = [cooked_meat, picasso_chicken, cheesecakes, lasagna, pancakes, azu, oyakodon]

    write_to_csv(product_list)
    write_to_csv(dish_list)
    l = read_from_csv()
    for el in l:
        print(el.title)



