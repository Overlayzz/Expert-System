import sys
from f import mode_selecting
from administation import GUI as administation_window
from answers_main import Dial as ans_window

from PyQt5 import QtWidgets


def log_uncaught_exceptions(ex_cls, ex, tb):
    text = f"{ex_cls.__name__}: {ex}:\n"
    import traceback
    text += ''.join(traceback.format_tb(tb))
    print(f"\n{text}\n")


sys.excepthook = log_uncaught_exceptions  # noqa


class Dial(QtWidgets.QMainWindow, mode_selecting.Ui_Dialog):

    def __init__(self):
        super().__init__()
        self.setupUi(self)  # инициализация дизайна
        self.setWindowTitle("Выбор режима")

        self.pushButton.clicked.connect(self.open_administrator_mode)
        self.pushButton_2.clicked.connect(self.open_user_mode)

    def open_administrator_mode(self):
        print("Отркываю администирование")
        self.hide()
        administration = administation_window()
        self.window = administration # noqa
        self.window.show()

    def open_user_mode(self):
        print("Отркываю вопросы")
        self.hide()
        ans = ans_window()
        self.window = ans  # noqa
        self.window.show()


def main():
    app = QtWidgets.QApplication(sys.argv)  # Новый экземпляр QApplication
    window = Dial()  # создаём объект класса приложения
    window.show()  # показываем окно
    app.exec_()  # запускаем приложение


if __name__ == '__main__':
    main()

# при изменении в таблице идёт проверка
# при добавлении создовать окно
