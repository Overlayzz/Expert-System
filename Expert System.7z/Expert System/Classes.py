class Product:

    def __init__(self, title, proteins, fat, carbohydrates, calories):
        self.title = title
        self.proteins = proteins
        self.fat = fat
        self.carbohydrates = carbohydrates
        self.calories = calories

    def get_title(self):
        return self.title


class Dish(Product):

    def __init__(self, title, proteins, fat, carbohydrates, calories, components_list, price):
        super().__init__(title, proteins, fat, carbohydrates, calories)

        self.components_list = components_list
        self.price = price
