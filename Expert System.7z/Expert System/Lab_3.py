#
# class Product:
#
#     def __init__(self, proteins, fats, carbohydrates, calories):
#         self.proteins = proteins
#         self.fats = fats
#         self.carbohydrates = carbohydrates
#         self.calories = calories
#
#
# class Egg(Product):
#
#     def __init__(self, proteins, fats, carbohydrates, calories, egg_category,expiration_date):
#         self.expiration_date = expiration_date
#         self.egg_category = egg_category
#         super().__init__(proteins, fats, carbohydrates, calories)
#
#     # def scramble(self):
#     #     self.calories += 243 - 157
#
#     def boil(self):
#         self.calories += 3
#
#     def __str__(self):
#         return f'Egg item:{self.proteins, self.fats, self.carbohydrates, self.calories}'
#
#     # def Poached(self):
#     #
#     # def Basted(self):
#     #
#     # def Steamed(self):
#
#
# class Milk(Product):
#
#     def __init__(self, proteins, fats, carbohydrates, calories, animal_type):
#         self.animal_type = animal_type
#         super().__init__(proteins, fats, carbohydrates, calories)
#
#     def add_name(self):
#         pass
#
#     def __str__(self):
#         return f'Egg item:{self.proteins, self.fats, self.carbohydrates, self.calories, self.animal_type}'
#
#
# class Omelette(Egg, Milk):
#
#     def __init__(self, proteins, fats, carbohydrates, calories, animal_type):
#         Egg.__init__(self, proteins, fats, carbohydrates, calories, None)
#         Milk.__init__(self, animal_type)
#
#
# if __name__ == '__main__':
#     egg = Egg(12, 12, 1, 157, '12.05.2000')
#     print(egg)
#     omelette = Omelette(12, 12, 1, 157, 'Dancing_cow')
#     pass

# 

class Mammal:
    class_instants = 0

    def __init__(self, type_of_diet, legs_num, arms_num, hunger):
        self.type_of_diet = type_of_diet
        self.legs_num = legs_num
        self.arms_num = arms_num
        self.hunger = hunger
        self.__class__.class_instants += 1

    def eat(self):
        self.hunger += 10

    @classmethod
    def get_instance(cls):
        return cls.class_instants

    def __str__(self):
        return f'-------------------' \
               f'\ntype_of_diet : {self.type_of_diet}' \
               f'\nlegs_num : {self.legs_num}' \
               f'\narms_num : {self.arms_num}' \
               f'\nhunger : {self.hunger}' \
               f'\n-------------------'


class Primates(Mammal):
    class_instants = 0

    def __init__(self, hunger, happiness):
        self.happiness = happiness
        super(Primates, self).__init__('pantograph', 2, 2, hunger)

    def say(self):
        print('*Monkey noises*')

    def play(self):
        self.happiness += 10

    def __str__(self):
        return f'-------------------' \
               f'\ntype_of_diet : {self.type_of_diet}' \
               f'\nlegs_num : {self.legs_num}' \
               f'\narms_num : {self.arms_num}' \
               f'\nhunger : {self.hunger}' \
               f'\nhappiness : {self.happiness}' \
               f'\n-------------------'

    @classmethod
    def get_instance(cls):
        return cls.class_instants


class Human(Primates):
    class_instants = 0

    def __init__(self, hunger, happiness, name):
        self.name = name
        super(Human, self).__init__(hunger, happiness)

    def say(self):
        print(f'Hi, I\'m {self.name}!')

    def work(self):
        self.happiness -= 10

    def __str__(self):
        return f'-------------------' \
               f'\ntype_of_diet : {self.type_of_diet}' \
               f'\nlegs_num : {self.legs_num}' \
               f'\narms_num : {self.arms_num}' \
               f'\nhunger : {self.hunger}' \
               f'\nhappiness : {self.happiness} ' \
               f'\nname : {self.name}' \
               f'\n-------------------'

    @classmethod
    def get_instance(cls):
        return cls.class_instants


if __name__ == '__main__':
    # млекопитающие
    mammal = Mammal(legs_num=2, arms_num=0, hunger=7 ,type_of_diet='Any')
    print(mammal)
    mammal.eat()
    print(mammal)

    print('\n\t', '-' * 30, '\n')

    # мартышки
    primate = Primates(happiness=2, hunger=10)
    print(primate)
    primate.eat()
    primate.play()
    print(primate)

    print('\n\t', '-' * 30, '\n')

    # люди
    peter = Human(happiness=10, hunger=15, name='Peter')
    peter_junior = Human(happiness=20, hunger=5, name='Peter') # создаём объект для демонстрации счётчика
    peter.say()
    print(peter)
    peter.play()
    print()
    print(peter)
    print(f'Human instance : {Human.get_instance()}')
