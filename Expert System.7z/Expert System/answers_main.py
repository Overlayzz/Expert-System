import csv
import sys

from PyQt5.QtWidgets import QTableWidgetItem

from f import answers

from PyQt5 import QtWidgets


def log_uncaught_exceptions(ex_cls, ex, tb):
    text = f"{ex_cls.__name__}: {ex}:\n"
    import traceback
    text += ''.join(traceback.format_tb(tb))
    print(f"\n{text}\n")


sys.excepthook = log_uncaught_exceptions  # noqa


class Dial(QtWidgets.QMainWindow, answers.Ui_Dialog):

    def __init__(self):
        super().__init__()
        self.setupUi(self)  # инициализация дизайна
        self.setWindowTitle("Вопросы")

        self.pushButton.clicked.connect(self.prev_question)
        self.pushButton_2.clicked.connect(self.next_question)

        self.page = 0

        self.pushButton.setDisabled(True)

        self.questions = [
            ["Для чего вы хотите изменить питание?",
             ["Похудеть ", "Набрать мышечную массу", "Перейти на здоровое питание", "Просто хочу вкусно поесть"]],
            ["Вы часто занимаетесь физической активностью:", ["Да", "Нет", "Иногда"]],
            ["Вам нужно спортивное питание:", ["Да, я профессиональный спортсмен", "Да, я поддерживаю форму",
                                               "Я хочу такое питание, но пока не занимаюсь", "Нет"]],
            ["У вас есть хронические заболевания:",
             ["Да, у меня ЖКТ", "У меня есть аллергия", "У меня сахарный диабет", "Нет"]]
        ]

        self.set_weights = [
            [[0, 0, 10, 20], [15, 30, 40, 50], [45, 70, 120, 120]],
            [[0, 0, 5, 13], [12, 16, 19, 22], [20, 25, 30, 30]],
            [[0, 0, 12, 25], [20, 40, 50, 60], [55, 75, 130, 130]],
            [[0, 0, 50, 150], [145, 265, 355, 450], [400, 700, 1000, 1000]]
        ]

        self.answers = [0] * len(self.questions)
        self.coefficient_weights = [0, 4, 5, 1]

        self.tableWidget.hide()

    def prev_question(self):
        self.page -= 1
        self.change_text()
        self.check_for_disable()
        print("Пред вопрос")

    def next_question(self):
        self.page += 1
        self.change_text()
        self.check_for_disable()
        self.write_answer()
        if self.page >= len(self.questions):
            self.show_results()

    def check_for_disable(self):
        if self.page <= 0:
            self.pushButton.setDisabled(True)
        else:
            self.pushButton.setDisabled(False)

    def read_csv(self, path='ClassesData.csv'):  # noqa
        with open(path, encoding='utf-8') as class_file:
            file_reader = csv.reader(class_file, delimiter=",")
            data = []
            for row in file_reader:
                if row[0] == "Dish":
                    data.append(row)

            return data

    def write_answer(self):
        if self.radioButton.isChecked():
            self.answers[self.page - 1] = 0
        elif self.radioButton_2.isChecked():
            self.answers[self.page - 1] = 1
        elif self.radioButton_3.isChecked():
            self.answers[self.page - 1] = 2
        elif self.radioButton_4.isChecked():
            self.answers[self.page - 1] = 3

    def hide_initial_elements(self):
        self.pushButton.hide()
        self.pushButton_2.hide()
        self.groupBox.hide()
        self.label.hide()

    def show_results(self):
        self.hide_initial_elements()

        dishes = self.find_dishes_for_user()
        if len(dishes) < 3:
            self.failier_notification()
        else:
            self.resize(870, 257)
            self.tableWidget.show()
            self.label.show()
            self.label.setText("Вам подойдут такие блюда как")
            self.tableWidget.setColumnCount(7)
            self.tableWidget.setHorizontalHeaderLabels(["Название", "Белки", "Жиры", "Углеводы", "Калории", "Состав", "Цена"])

            i = 0

            for row in dishes:
                self.tableWidget.insertRow(self.tableWidget.rowCount())
                for j in range(1, len(row)):
                    cell_item = QTableWidgetItem()
                    cell_item.setText(row[j])
                    self.tableWidget.setItem(i, j - 1, cell_item)
                i += 1

    def change_text(self):
        if self.page < len(self.questions):
            self.groupBox.setTitle(self.questions[self.page][0])
            self.radioButton.setText(self.questions[self.page][1][0])
            self.radioButton_2.setText(self.questions[self.page][1][1])
            self.radioButton_3.setText(self.questions[self.page][1][2])
            if len(self.questions[self.page][1]) == 4:
                self.radioButton_4.show()
                self.radioButton_4.setText(self.questions[self.page][1][3])
            else:
                self.radioButton_4.hide()

    def get_fuzzy_sets(self):
        self.questions_process()
        return [self.set_weights[0][self.coefficient_weights[0]], self.set_weights[1][self.coefficient_weights[1]],
                self.set_weights[2][self.coefficient_weights[2]], self.set_weights[3][self.coefficient_weights[3]]]

    def questions_process(self):

        if self.answers[0] == 0:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 2
            self.coefficient_weights[2] -= 1
            self.coefficient_weights[3] -= 1
        elif self.answers[0] == 1:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] += 1
            self.coefficient_weights[2] += 1
            self.coefficient_weights[3] -= 1
        elif self.answers[0] == 2:
            self.coefficient_weights[1] -= 1
        elif self.answers[0] == 3:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] += 1
            self.coefficient_weights[2] += 1

        if self.answers[1] == 0:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] += 1
            self.coefficient_weights[2] -= 1
        elif self.answers[1] == 1:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
        elif self.answers[1] == 2:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] -= 1

        if self.answers[2] == 0:
            self.coefficient_weights[0] += 2
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] += 2
            self.coefficient_weights[3] += 1
        elif self.answers[2] == 1:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] += 1
            self.coefficient_weights[3] += 1
        elif self.answers[2] == 2:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] -= 1
        elif self.answers[2] == 3:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] += 1
            self.coefficient_weights[2] += 1
            self.coefficient_weights[3] += 1

        if self.answers[3] == 0:
            self.coefficient_weights[0] -= 2
            self.coefficient_weights[1] = 0
            self.coefficient_weights[2] += 1
        elif self.answers[3] == 1:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] += 1
        elif self.answers[3] == 2:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] -= 1
            self.coefficient_weights[2] -= 1
        elif self.answers[3] == 3:
            self.coefficient_weights[0] += 1
            self.coefficient_weights[1] += 1
            self.coefficient_weights[2] += 1
            self.coefficient_weights[3] += 1

        if self.coefficient_weights[0] <= 2:
            self.coefficient_weights[0] = 0
        elif self.coefficient_weights[0] <= 4:
            self.coefficient_weights[0] = 1
        else:
            self.coefficient_weights[0] = 2

        if self.coefficient_weights[1] <= 1:
            self.coefficient_weights[1] = 0
        elif self.coefficient_weights[1] <= 2:
            self.coefficient_weights[1] = 1
        else:
            self.coefficient_weights[1] = 2

        if self.coefficient_weights[2] <= 2:
            self.coefficient_weights[2] = 0
        elif self.coefficient_weights[2] <= 4:
            self.coefficient_weights[2] = 1
        else:
            self.coefficient_weights[2] = 2

        if self.coefficient_weights[3] <= 0:
            self.coefficient_weights[3] = 0
        elif self.coefficient_weights[3] <= 1:
            self.coefficient_weights[3] = 1
        else:
            self.coefficient_weights[3] = 2

    def find_dishes_for_user(self):
        fuzzy_sets = self.get_fuzzy_sets()
        dishes = self.read_csv()
        user_dishes = []
        print(fuzzy_sets)
        for dish in dishes:
            if self.m_nechet(fuzzy_sets[0], float(dish[2])) > 0 and self.m_nechet(fuzzy_sets[1], float(dish[3])) > 0 and\
                    self.m_nechet(fuzzy_sets[2], float(dish[4])) > 0 and self.m_nechet(fuzzy_sets[3], float(dish[5])) > 0:
                user_dishes.append(dish)
        print(user_dishes)
        return user_dishes

    def m_nechet(self, l: list, x):
        a = l[0]
        b = l[1]
        c = l[2]
        d = l[3]
        if a <= x <= b:
            m = 1 - float((b - x) / (b - a))
        elif b <= x <= c:
            m = 1
        elif c <= x <= d:
            m = 1 - float((x - c) / (d - c))
        else:
            m = 0
        return m

    def failier_notification(self):
        self.label.show()
        self.label.setText("Извините, не удалось составить для вас меню")


def main():
    app = QtWidgets.QApplication(sys.argv)  # Новый экземпляр QApplication
    window = Dial()  # создаём объект класса приложения
    window.show()  # показываем окно
    app.exec_()  # запускаем приложение


if __name__ == '__main__':
    main()

# при изменении в таблице идёт проверка
# при добавлении создовать окно
